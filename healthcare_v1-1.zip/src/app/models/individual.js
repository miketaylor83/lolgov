"use strict";
var Individual = (function () {
    function Individual() {
    }
    return Individual;
}());
exports.Individual = Individual;
var UserInputs = (function () {
    function UserInputs() {
    }
    return UserInputs;
}());
exports.UserInputs = UserInputs;
//# sourceMappingURL=individual.js.map